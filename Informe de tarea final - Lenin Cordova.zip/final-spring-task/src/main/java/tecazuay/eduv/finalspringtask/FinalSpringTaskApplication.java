package tecazuay.eduv.finalspringtask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalSpringTaskApplication {

    public static void main(String[] args) {
        SpringApplication.run(FinalSpringTaskApplication.class, args);
    }

}
